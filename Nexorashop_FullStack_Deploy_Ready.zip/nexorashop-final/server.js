require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { Pool } = require('pg');
const Razorpay = require('razorpay');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
const isProd = process.env.NODE_ENV === 'production';
const port = Number(process.env.PORT || 3000);
if (!process.env.DATABASE_URL) console.warn('WARNING: DATABASE_URL is not set. Set it before starting the store.');
if (!process.env.ADMIN_PASSWORD || !process.env.SESSION_SECRET) console.warn('WARNING: Set ADMIN_PASSWORD and SESSION_SECRET before deployment.');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL && !/localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL) ? { rejectUnauthorized: false } : undefined });
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;
const publicDir = path.join(__dirname, 'public');

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cookieParser());
app.use(express.json({ limit: '100kb', verify: (req, _res, buf) => { if (req.originalUrl === '/api/payments/webhook') req.rawBody = Buffer.from(buf); } }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(publicDir));

const seedProducts = [
  [1,'Everyday Stainless Steel Bottle','Home & Kitchen',349,499,'🥤','POPULAR','#e6f4ff','A reusable bottle for daily use.',30],
  [2,'Wireless Bluetooth Earbuds','Electronics',799,1199,'🎧','TRENDING','#eaeaff','Compact wireless audio accessory.',20],
  [3,'Minimal Desk Organiser','Home & Kitchen',299,399,'🗂️','USEFUL FIND','#fff0e2','Keep everyday desk items organised.',25],
  [4,'Mobile Phone Stand','Mobile Accessories',199,299,'📱','DAILY ESSENTIAL','#e6f7f0','A handy stand for your phone.',40],
  [5,'Compact Travel Backpack','Fashion & Travel',699,999,'🎒','POPULAR','#eaf0ff','A versatile bag for everyday travel.',15],
  [6,'LED Night Lamp','Home & Kitchen',399,599,'💡','SMART PICK','#fff5d8','Soft lighting for a bedside or desk.',18],
  [7,'Fitness Resistance Bands','Fitness',249,399,'💪','ACTIVE LIFE','#ffe9e8','Simple fitness accessory for workouts.',35],
  [8,'Everyday Sunglasses','Fashion & Travel',299,499,'🕶️','STYLE PICK','#e6f5ff','A lightweight everyday style accessory.',22]
];
async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, price INTEGER NOT NULL CHECK(price >= 0), old_price INTEGER NOT NULL DEFAULT 0,
    emoji TEXT NOT NULL DEFAULT '📦', label TEXT NOT NULL DEFAULT 'NEW', tint TEXT NOT NULL DEFAULT '#e6f4ff', description TEXT NOT NULL DEFAULT '',
    stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0), active BOOLEAN NOT NULL DEFAULT TRUE, supplier_name TEXT NOT NULL DEFAULT '', supplier_url TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS orders (
    id BIGSERIAL PRIMARY KEY, order_code TEXT UNIQUE NOT NULL, customer_name TEXT NOT NULL, phone TEXT NOT NULL, pincode TEXT NOT NULL,
    address TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL, payment_method TEXT NOT NULL, payment_status TEXT NOT NULL DEFAULT 'Pending',
    order_status TEXT NOT NULL DEFAULT 'New', subtotal INTEGER NOT NULL CHECK(subtotal >= 0), items JSONB NOT NULL,
    razorpay_order_id TEXT, razorpay_payment_id TEXT, tracking_number TEXT NOT NULL DEFAULT '', admin_note TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS store_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
  const count = await pool.query('SELECT COUNT(*)::int AS n FROM products');
  if (count.rows[0].n === 0) {
    for (const p of seedProducts) await pool.query(`INSERT INTO products(id,name,category,price,old_price,emoji,label,tint,description,stock) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`, p);
    await pool.query(`SELECT setval(pg_get_serial_sequence('products','id'), (SELECT COALESCE(MAX(id),1) FROM products))`);
  }
  const defaults = [['store_name',process.env.STORE_NAME || 'Nexorashop'],['shipping_fee','0'],['support_email',process.env.STORE_EMAIL || ''],['support_phone','']];
  for (const [k,v] of defaults) await pool.query('INSERT INTO store_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO NOTHING',[k,v]);
}
function makeToken() { const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 8*60*60*1000 })).toString('base64url'); const sig = crypto.createHmac('sha256', process.env.SESSION_SECRET || 'unsafe-dev-secret').update(payload).digest('base64url'); return `${payload}.${sig}`; }
function validToken(token) { try { const [p,s] = String(token||'').split('.'); if (!p || !s) return false; const expected = crypto.createHmac('sha256', process.env.SESSION_SECRET || 'unsafe-dev-secret').update(p).digest(); const got = Buffer.from(s,'base64url'); return got.length === expected.length && crypto.timingSafeEqual(got,expected) && JSON.parse(Buffer.from(p,'base64url').toString()).exp > Date.now(); } catch { return false; } }
function adminOnly(req,res,next) { if (!validToken(req.cookies.nx_admin)) return res.status(401).json({ error:'Admin login required.' }); next(); }
function text(v,max=300) { return String(v ?? '').trim().slice(0,max); }
function sendMail(subject, textBody) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.STORE_EMAIL) return Promise.resolve(false);
  const transporter = nodemailer.createTransport({ host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT||587), secure:String(process.env.SMTP_SECURE)==='true', auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS} });
  return transporter.sendMail({ from:process.env.FROM_EMAIL || process.env.SMTP_USER, to:process.env.STORE_EMAIL, subject, text:textBody }).then(()=>true).catch(e=>{console.error('Email notification failed:',e.message);return false;});
}
function publicProduct(p) { return {id:p.id,name:p.name,category:p.category,price:p.price,oldPrice:p.old_price,emoji:p.emoji,label:p.label,tint:p.tint,description:p.description,stock:p.stock}; }
app.get('/api/health', async (_req,res) => { try { await pool.query('SELECT 1'); res.json({ok:true, database:'connected', onlinePayments:!!razorpay}); } catch { res.status(503).json({ok:false,database:'unavailable'}); } });
app.get('/api/products', async (_req,res) => { try { const r=await pool.query('SELECT * FROM products WHERE active=true ORDER BY id'); res.json({products:r.rows.map(publicProduct)}); } catch(e) { console.error(e); res.status(503).json({error:'Store is starting or database is unavailable.'}); } });
app.get('/api/store', async (_req,res) => { try { const r=await pool.query('SELECT key,value FROM store_settings'); const settings=Object.fromEntries(r.rows.map(x=>[x.key,x.value])); res.json({name:settings.store_name||'Nexorashop',shippingFee:Number(settings.shipping_fee||0),supportEmail:settings.support_email||'',supportPhone:settings.support_phone||'',razorpayEnabled:!!razorpay,razorpayKeyId:razorpay?process.env.RAZORPAY_KEY_ID:''}); } catch { res.json({name:'Nexorashop',shippingFee:0,razorpayEnabled:false}); } });
app.post('/api/admin/login', rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:'draft-7',legacyHeaders:false}), async (req,res) => { if (!process.env.ADMIN_PASSWORD || !process.env.SESSION_SECRET) return res.status(503).json({error:'Set ADMIN_PASSWORD and SESSION_SECRET in deployment settings first.'}); const pass=String(req.body.password||''); if (pass.length>200 || !(await bcrypt.compare(pass, await bcrypt.hash(process.env.ADMIN_PASSWORD, 10)))) return res.status(401).json({error:'Incorrect password.'}); res.cookie('nx_admin',makeToken(),{httpOnly:true,secure:isProd,sameSite:'strict',maxAge:8*60*60*1000,path:'/'}); res.json({ok:true}); });
app.post('/api/admin/logout',(_req,res)=>{res.clearCookie('nx_admin',{httpOnly:true,secure:isProd,sameSite:'strict',path:'/'});res.json({ok:true});});
app.get('/api/admin/me',adminOnly,(_req,res)=>res.json({ok:true}));
app.get('/api/admin/orders',adminOnly,async(req,res)=>{try{const status=text(req.query.status,40);const r=status?await pool.query('SELECT * FROM orders WHERE order_status=$1 ORDER BY created_at DESC LIMIT 500',[status]):await pool.query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 500');res.json({orders:r.rows});}catch(e){console.error(e);res.status(500).json({error:'Could not load orders.'});}});
app.patch('/api/admin/orders/:id',adminOnly,async(req,res)=>{const status=text(req.body.status,40), tracking=text(req.body.trackingNumber,100), note=text(req.body.adminNote,1000);const allowed=['New','Confirmed','Processing','Shipped','Delivered','Cancelled','Return requested','Refunded'];if(!allowed.includes(status))return res.status(400).json({error:'Invalid order status.'});try{const r=await pool.query('UPDATE orders SET order_status=$1,tracking_number=$2,admin_note=$3,updated_at=NOW() WHERE id=$4 RETURNING *',[status,tracking,note,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Order not found.'});res.json({order:r.rows[0]});}catch(e){console.error(e);res.status(500).json({error:'Could not update order.'});}});
app.get('/api/admin/products',adminOnly,async(_req,res)=>{const r=await pool.query('SELECT * FROM products ORDER BY id');res.json({products:r.rows});});
app.post('/api/admin/products',adminOnly,async(req,res)=>{const b=req.body;const name=text(b.name,160),category=text(b.category,80);const price=Number(b.price),stock=Number(b.stock);if(!name||!category||!Number.isInteger(price)||price<0||!Number.isInteger(stock)||stock<0)return res.status(400).json({error:'Enter valid product name, category, price and stock.'});try{const r=await pool.query(`INSERT INTO products(name,category,price,old_price,emoji,label,tint,description,stock,active,supplier_name,supplier_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,[name,category,price,Math.max(0,Number(b.oldPrice)||0),text(b.emoji,12)||'📦',text(b.label,40)||'NEW',/^#[0-9a-fA-F]{6}$/.test(b.tint)?b.tint:'#e6f4ff',text(b.description,500),stock,b.active!==false,text(b.supplierName,160),text(b.supplierUrl,500)]);res.status(201).json({product:r.rows[0]});}catch(e){console.error(e);res.status(500).json({error:'Could not save product.'});}});
app.patch('/api/admin/products/:id',adminOnly,async(req,res)=>{const b=req.body;const price=Number(b.price),stock=Number(b.stock);if(!text(b.name,160)||!text(b.category,80)||!Number.isInteger(price)||price<0||!Number.isInteger(stock)||stock<0)return res.status(400).json({error:'Enter valid product name, category, price and stock.'});try{const r=await pool.query(`UPDATE products SET name=$1,category=$2,price=$3,old_price=$4,emoji=$5,label=$6,tint=$7,description=$8,stock=$9,active=$10,supplier_name=$11,supplier_url=$12,updated_at=NOW() WHERE id=$13 RETURNING *`,[text(b.name,160),text(b.category,80),price,Math.max(0,Number(b.oldPrice)||0),text(b.emoji,12)||'📦',text(b.label,40)||'NEW',/^#[0-9a-fA-F]{6}$/.test(b.tint)?b.tint:'#e6f4ff',text(b.description,500),stock,b.active!==false,text(b.supplierName,160),text(b.supplierUrl,500),req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Product not found.'});res.json({product:r.rows[0]});}catch(e){console.error(e);res.status(500).json({error:'Could not update product.'});}});
app.delete('/api/admin/products/:id',adminOnly,async(req,res)=>{try{await pool.query('UPDATE products SET active=false,updated_at=NOW() WHERE id=$1',[req.params.id]);res.json({ok:true});}catch(e){res.status(500).json({error:'Could not archive product.'});}});
app.get('/api/admin/settings',adminOnly,async(_req,res)=>{const r=await pool.query('SELECT key,value FROM store_settings');res.json({settings:Object.fromEntries(r.rows.map(x=>[x.key,x.value]))});});
app.put('/api/admin/settings',adminOnly,async(req,res)=>{const pairs=[['store_name',text(req.body.store_name,100)||'Nexorashop'],['shipping_fee',String(Math.max(0,Math.round(Number(req.body.shipping_fee)||0)))],['support_email',text(req.body.support_email,200)],['support_phone',text(req.body.support_phone,30)]];for(const [k,v] of pairs)await pool.query('INSERT INTO store_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value',[k,v]);res.json({ok:true});});
async function createOrder(req,res){const b=req.body||{},customer=b.customer||{};const name=text(customer.name,80),phone=text(customer.phone,10),pincode=text(customer.pincode,6),address=text(customer.address,500),city=text(customer.city,80),state=text(customer.state,80);if(!name||!/^[6-9]\d{9}$/.test(phone)||!/^[1-9]\d{5}$/.test(pincode)||!address||!city||!state||!Array.isArray(b.items)||!b.items.length||b.items.length>50)return res.status(400).json({error:'Please check your delivery details and cart.'});const client=await pool.connect();try{await client.query('BEGIN');let items=[],subtotal=0;for(const entry of b.items){const id=Number(entry.id),qty=Number(entry.quantity);if(!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>20)throw new Error('Invalid item quantity.');const found=await client.query('SELECT * FROM products WHERE id=$1 AND active=true FOR UPDATE',[id]);if(!found.rowCount)throw new Error('A product is no longer available.');const p=found.rows[0];if(p.stock<qty)throw new Error(`${p.name} is out of stock or has insufficient stock.`);items.push({id:p.id,name:p.name,unitPrice:p.price,quantity:qty,lineTotal:p.price*qty});subtotal+=p.price*qty;}
 const set=await client.query("SELECT value FROM store_settings WHERE key='shipping_fee'");const shippingFee=Number(set.rows[0]?.value||0);const total=subtotal+shippingFee;const method=b.paymentMethod==='Razorpay'&&razorpay?'Razorpay':'Cash on Delivery';const orderCode='NXR-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase();let rzOrder=null;if(method==='Razorpay'){rzOrder=await razorpay.orders.create({amount:total*100,currency:'INR',receipt:orderCode,notes:{order_code:orderCode}});}
 const inserted=await client.query(`INSERT INTO orders(order_code,customer_name,phone,pincode,address,city,state,payment_method,payment_status,subtotal,items,razorpay_order_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id,order_code,subtotal,payment_method,payment_status,order_status,items,created_at`,[orderCode,name,phone,pincode,address,city,state,method,method==='Razorpay'?'Awaiting payment':'Pending collection',total,JSON.stringify(items),rzOrder?.id||null]);for(const item of items)await client.query('UPDATE products SET stock=stock-$1,updated_at=NOW() WHERE id=$2',[item.quantity,item.id]);await client.query('COMMIT');const order=inserted.rows[0];sendMail(`New Nexorashop order ${orderCode}`,`New order: ${orderCode}\nCustomer: ${name}\nPhone: ${phone}\nAddress: ${address}, ${city}, ${state} ${pincode}\nPayment: ${method}\nTotal: INR ${total}\nItems: ${items.map(i=>`${i.name} x ${i.quantity}`).join(', ')}`).catch(()=>{});res.status(201).json({order,shippingFee,total,razorpay:rzOrder?{keyId:process.env.RAZORPAY_KEY_ID,orderId:rzOrder.id,amount:rzOrder.amount,currency:rzOrder.currency,name:process.env.STORE_NAME||'Nexorashop',description:`Order ${orderCode}`,prefill:{name,contact:phone}}:null});
 }catch(e){await client.query('ROLLBACK');res.status(400).json({error:e.message||'Could not place order.'});}finally{client.release();}}
app.post('/api/orders',rateLimit({windowMs:10*60*1000,limit:12,standardHeaders:'draft-7',legacyHeaders:false}),createOrder);
app.post('/api/payments/verify',rateLimit({windowMs:10*60*1000,limit:20,standardHeaders:'draft-7',legacyHeaders:false}),async(req,res)=>{if(!razorpay)return res.status(503).json({error:'Online payment is not configured.'});const {orderId,paymentId,signature}=req.body||{};if(!orderId||!paymentId||!signature)return res.status(400).json({error:'Missing payment verification details.'});const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');if(String(signature).length!==expected.length || !crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(String(signature))))return res.status(400).json({error:'Payment verification failed.'});try{const r=await pool.query("UPDATE orders SET payment_status='Paid',razorpay_payment_id=$1,updated_at=NOW() WHERE razorpay_order_id=$2 RETURNING order_code",[paymentId,orderId]);if(!r.rowCount)return res.status(404).json({error:'Order not found.'});res.json({ok:true,orderCode:r.rows[0].order_code});}catch(e){console.error(e);res.status(500).json({error:'Could not confirm payment.'});}});
app.post('/api/payments/webhook',async(req,res)=>{if(!process.env.RAZORPAY_WEBHOOK_SECRET)return res.status(503).send('Webhook not configured');const sig=req.headers['x-razorpay-signature'];const expected=crypto.createHmac('sha256',process.env.RAZORPAY_WEBHOOK_SECRET).update(req.rawBody || Buffer.from('')).digest('hex');if(!sig||sig!==expected)return res.status(400).send('Invalid signature');try{const event=JSON.parse(req.body.toString());if(event.event==='payment.captured'){const payment=event.payload.payment.entity;await pool.query("UPDATE orders SET payment_status='Paid',razorpay_payment_id=$1,updated_at=NOW() WHERE razorpay_order_id=$2",[payment.id,payment.order_id]);}res.json({received:true});}catch(e){console.error(e);res.status(400).send('Invalid event');}});
app.get('/admin',(_req,res)=>res.sendFile(path.join(publicDir,'admin.html')));
app.get('*',(req,res,next)=>{if(req.path.startsWith('/api/'))return res.status(404).json({error:'API route not found.'});res.sendFile(path.join(publicDir,'index.html'));});
initDb().then(()=>app.listen(port,()=>console.log(`Nexorashop listening on ${port}`))).catch(e=>{console.error('Database initialization failed:',e.message);process.exit(1);});
