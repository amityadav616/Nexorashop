# Nexorashop लाइव करने की हिंदी गाइड

## इस ZIP में क्या तैयार है?
- ग्राहक की वेबसाइट: प्रोडक्ट, सर्च, कैटेगरी, कार्ट और वेबसाइट चेकआउट
- PostgreSQL डेटाबेस के साथ सर्वर-साइड ऑर्डर सेव करना
- `/admin` पर पासवर्ड-सुरक्षित एडमिन पैनल
- प्रोडक्ट जोड़ना/बदलना/छिपाना, स्टॉक और सप्लायर की जानकारी रखना
- ऑर्डर स्टेटस, ट्रैकिंग नंबर और नोट अपडेट करना
- Razorpay पेमेंट और ईमेल नोटिफिकेशन के लिए वैकल्पिक कॉन्फ़िगरेशन

## लाइव करने के लिए आपको क्या करना होगा?
1. **डेटाबेस:** Neon या अन्य PostgreSQL सेवा पर डेटाबेस बनाएं और connection string लें।
2. **होस्टिंग:** प्रोजेक्ट को GitHub repository में डालें; `.env` या किसी secret को GitHub पर कभी न डालें। Render पर Node web service बनाएं। Build command `npm install`, Start command `npm start`, health path `/api/health` रखें।
3. **Environment variables:** `.env.example` देखकर Render के Environment section में `DATABASE_URL`, `ADMIN_PASSWORD`, `SESSION_SECRET`, `NODE_ENV=production`, `STORE_NAME=Nexorashop` सेट करें। Admin password लंबा और अलग रखें; `SESSION_SECRET` कम-से-कम 32 random characters का हो।
4. **पहला स्टार्ट:** सर्वर डेटाबेस टेबल और उदाहरण वाले प्रोडक्ट अपने-आप बनाएगा। Render का URL खोलें; एडमिन के लिए `https://आपका-url/admin` खोलें।
5. **डोमेन:** डोमेन registrar से खरीदें, Render में Custom Domain जोड़ें और registrar के DNS records सेट करें। HTTPS चालू होने के बाद `PUBLIC_BASE_URL` में असली HTTPS URL दें।
6. **असली प्रोडक्ट:** Admin → Products & suppliers में असली नाम, कीमत, स्टॉक, सप्लायर और लिंक डालें। पहले से डाले 8 प्रोडक्ट सिर्फ नमूने हैं।
7. **पेमेंट:** Razorpay merchant account और KYC पूरा होने पर Razorpay Key ID/Secret hosting के environment में डालें। Webhook URL `https://आपका-डोमेन/api/payments/webhook` बनाएं और webhook secret सेट करें। पहले Test Mode में पूरा परीक्षण करें।
8. **ईमेल:** ईमेल सेवा के SMTP विवरण environment variables में डालें। फिर एक परीक्षण ऑर्डर देकर देखें कि store email पर notification आता है या नहीं।
9. **डिलीवरी और नियम:** COD, courier, delivery charges, returns/refunds, privacy, terms, GST/invoice और consumer rules के विवरण सत्यापित करके `public/policies.html` अपडेट करें।

## क्या अभी अपने-आप नहीं होगा?
- वेबसाइट अभी आपके डोमेन पर प्रकाशित नहीं की गई है; उसके लिए आपके hosting/database/domain accounts में लॉगिन और DNS setup आवश्यक है।
- सप्लायर का नाम/URL सेव करने की सुविधा है, लेकिन किसी supplier से automatic order या stock sync नहीं है। इसके लिए supplier API और अधिकृत account चाहिए।
- Courier API/automatic shipping label नहीं जुड़ा; admin में tracking number हाथ से डाला जा सकता है।
- Razorpay और SMTP credentials दिए बिना online payment और email notification चालू नहीं होंगे।
- असली products, supplier costs, GST details, store address, support phone/email और return policy अभी आपसे सत्यापित होने बाकी हैं।

**महत्वपूर्ण:** वास्तविक ग्राहक डेटा/पैसे लेने से पहले live deployment, database backup, test orders, payment verification, returns/refunds और delivery workflow को अच्छी तरह जाँचें। Free hosting/database की limits, sleep, backup और data-retention नियम बदल सकते हैं; live business के लिए वर्तमान provider terms पढ़ें।
