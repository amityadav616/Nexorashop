# Nexorashop — deploy-ready full-stack starter

India-focused mixed-products storefront with server-side PostgreSQL storage, protected admin panel, stock-aware checkout, optional Razorpay payments, and optional email notifications.

## Important reality check
This is a deploy-ready code package, **not a website already published on a domain**. You must create/connect hosting and database accounts and add your private credentials. Product entries are sample placeholders; confirm products, prices, stock, suppliers, shipping, returns and business details before taking real orders. No supplier API is connected by default.

## Features
- Responsive blue/white storefront, search, category filtering and cart
- Checkout sends orders to the server; server recalculates price/stock from PostgreSQL
- PostgreSQL order/product database; stock is checked and reserved on order creation
- Protected admin login at `/admin`; view orders, update status, add/edit/hide products, store supplier name/link, tracking number and internal notes
- Optional Razorpay checkout and server-side signature verification + webhook
- Optional SMTP email notification on new orders
- Configurable store name, flat shipping fee, support email and phone
- Security headers, request limits, httpOnly admin cookie and server-only secrets

## 1. Create database
Create a PostgreSQL database, for example on Neon or another PostgreSQL provider. Copy its connection string. For production, use the provider's SSL connection string.

## 2. Deploy the app
1. Upload this project to a private/public GitHub repository (never upload `.env`).
2. Create a web service on Render and connect the repository. Build command: `npm install`; start command: `npm start`; health path: `/api/health`.
3. Set environment variables from `.env.example` in Render. Required: `DATABASE_URL`, `ADMIN_PASSWORD`, `SESSION_SECRET`, `NODE_ENV=production`, `STORE_NAME`. Use a long unique admin password and a random secret of at least 32 characters.
4. First startup creates tables and seeds sample products. Visit the provided Render URL and `/admin`.
5. Render free instances may sleep, and free database availability/retention/pricing changes; check current provider terms. For a real shop, choose hosting/database plans that meet uptime, backup and data-retention needs.

## 3. Domain
Buy a domain from a registrar, then add it in the hosting provider's custom-domain settings and follow its DNS instructions. Wait for DNS and HTTPS certificate provisioning. Set `PUBLIC_BASE_URL` to the final HTTPS URL. Domain purchase and DNS cannot be done from this code package without your account.

## 4. Products and suppliers
Login at `/admin` and use **Products & suppliers** to add verified product details, retail price, stock and supplier name/link. The eight seeded items are examples, not verified supplier listings or commitments. Check wholesale cost, GST invoice, shipping, return policy, quality, stock and delivery times yourself. Automated supplier fulfilment requires an API and authorized supplier account; supplier URL fields are reference notes only.

## 5. Online payments (optional)
1. Create and verify a Razorpay merchant account.
2. Add the test/live `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` to hosting environment variables. Do not put secrets in browser files.
3. Configure Razorpay webhook URL: `https://YOUR-DOMAIN/api/payments/webhook`, subscribe to `payment.captured`, and set `RAZORPAY_WEBHOOK_SECRET` to the webhook secret.
4. Test with test-mode keys before switching to live keys. The website offers online payment only if both Razorpay key values exist.
5. Verify settlement, refund, cancellation and webhook behaviour with the gateway before taking customer money.

## 6. Email notifications (optional)
Configure SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS, STORE_EMAIL and FROM_EMAIL in hosting settings. Use an email provider/account that permits transactional mail. New order notifications go to STORE_EMAIL. SMTP failure is logged server-side; it does not cancel the order.

## Before accepting live orders
- Replace all sample products and verify pricing/stock.
- Set actual store contact details and write accurate shipping, return/refund, privacy, terms, GST/invoice and consumer-law information in `public/policies.html`.
- Confirm COD availability, courier partner, serviceable PIN codes, RTO/return costs and fulfilment steps.
- Enable database backups, monitor logs, test admin access, payment webhooks, duplicate submissions, cancellations and refunds.
- Do not share admin password or payment secrets. Do not put secrets into frontend JavaScript or Git.
- This starter does not yet integrate any supplier's API or courier/shipping label API. Admin status/tracking fields are manual until you connect a courier API.

## Local development
Requires Node.js 20+ and PostgreSQL. Copy `.env.example` to `.env`, fill in required values, then run:

```bash
npm install
npm start
```

Open `http://localhost:3000` and `http://localhost:3000/admin`. Keep `.env` private.
